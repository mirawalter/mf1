About
============
Currently, in odoo, you can not create a project/task from sale order for non-service products (consumable products or stockable products). Our module will help to enable service tracking (create project/task) for non-service products. You can see service tracking options for non-service products like,

1) Don't create a task: When you create the sale order do not create any task or project.
2) Create a task in an existing project: When you create the sale order create tasks in an existing project not in the new project.
3) Create a task in a new project: When you create the sale order create tasks in the new project not in an existing project.
4) Create a new project but no task: When you create the sale order create a new project but not create the task.

Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list.
5) search module name and hit install button.

Any Problem with module?
=====================================
Please create your ticket here https://softhealer.com/support

Softhealer Technologies Doubt/Inquiry/Sales/Customization Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: support@softhealer.com
Website: https://softhealer.com
