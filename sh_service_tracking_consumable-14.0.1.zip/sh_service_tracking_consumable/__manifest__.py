# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.
{
    "name": "Service Tracking For Non Service Products",
    "author": "Softhealer Technologies",
    "license": "OPL-1",
    "support": "support@softhealer.com",
    "website": "https://www.softhealer.com",
    "category": "Sales",
    "summary": "Consumable Products Service Tracking, Manage Consumable Products, Consumable Products With Task, Consumable Product With Project, Service Tracking With Products, Consumable Product With Tracking Odoo",
    "description": """Currently, in odoo, you can not create a project/task from sale order for non-service products (consumable products or stockable products). Our module will help to enable service tracking (create project/task) for non-service products. You can see service tracking options for non-service products like,1) Don't create a task: When you create the sale order do not create any task or project.
2) Create a task in an existing project: When you create the sale order create tasks in an existing project not in the new project.
3) Create a task in a new project: When you create the sale order create tasks in the new project not in an existing project.
4) Create a new project but no task: When you create the sale order create a new project but not create the task. Service Tracking For Non Service Products Odoo, Service Tracking In Consumable Products, Manage Consumable Products With Task, Consumable Product With Project, Service Tracking With Products, Consumable Product With Tracking Odoo, Consumable Products Service Tracking, Manage Consumable Products, Consumable Products With Task, Consumable Product With Project, Service Tracking With Products, Consumable Product With Tracking Odoo""",
    "version": "14.0.1",
    "depends": ['sale_timesheet'],
    "data": [
        'views/product_view.xml',
    ],

    "images": ['static/description/background.png'],
    "auto_install": False,
    "application": True,
    "installable": True,
    "price": 30,
    "currency": 'EUR',
}
