# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from odoo import models, api


class ShProductTemplate(models.Model):
    _inherit = 'product.template'
    

class SOLine(models.Model):
    _inherit = 'sale.order.line'
    
    @api.depends('product_id')
    def _compute_is_service(self):
        for so_line in self:
            if so_line.product_id:
                so_line.is_service = True
            else:
                so_line.is_service = False
