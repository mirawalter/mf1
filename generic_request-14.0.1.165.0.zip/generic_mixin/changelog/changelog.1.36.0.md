Added new function `deactivate_records_for_model` in `tests.common` module.
This function could be used in tests to deactivate records created by
installed but not activated (yet) modules.
