Added new function `generic_mixin.tools.sql.create_sql_view`,
that could be used to simplify creation of postgresql views.
