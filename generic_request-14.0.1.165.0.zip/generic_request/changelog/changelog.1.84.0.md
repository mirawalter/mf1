Added *Requests* page to user form view, that is used to display request statistics for user.
