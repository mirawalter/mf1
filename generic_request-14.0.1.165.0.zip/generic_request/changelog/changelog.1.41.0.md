Introduced *Request Creation Templates* feature,
that have to be used mostly by other modules to create requests with default values.
