Changed status view in requests.
Now there is only the current status of request.
