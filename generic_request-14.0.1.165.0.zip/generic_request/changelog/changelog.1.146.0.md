Added option in configuration to show/hide searchpanel on requests view
