Merge the generic_request_reopen_as module into the generic_request module
