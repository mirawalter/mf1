Added new request stage type 'Progress'
