from .tools.utils import helper_get_many2one_info_data
