
=> 14.0.0.1 : Improve Invoice for view for Boolean fields.
